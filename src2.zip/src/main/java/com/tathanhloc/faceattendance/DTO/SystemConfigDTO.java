package com.tathanhloc.faceattendance.DTO;

public class SystemConfigDTO {
}
